library(tidyverse)
library(gtsummary)
library(here)
library(dplyr)
# Customization of `tbl_summary()`

tbl_summary(
						covid_testing,
					  by = gender,
	 				include = c(age, pan_day, result, payor_group, demo_group, patient_class))

tbl_summary(
	covid_testing,
	by = gender,
	include = c(age, pan_day, result, payor_group, demo_group, patient_class),
    label = list(
		pan_day ~ "Pandemic day",
		payor_group ~ "Payor",
		demo_group ~ "Demographic",
		patient_class ~ "Patient class",
		age ~ "Age",
		result ~ "Result"
	),
	missing_text = "Missing")

c2 <- covid_testing %>% mutate(Demographic = factor(demo_group, labels = c("client","patient", "other adult", "misc adult", "unidentified")),
			  Result = factor(result, labels = c("positive", "negative", "invalid")))


tbl_uvregression(
       c2,
	y = age,
	include = c(Demographic, gender, result),
	method = lm)

hist(covid_testing$pan_day)

mean <- function(x){
	m <- mean(x)
	return (m)
}

mean(c2$age)

sd <- function(x){
	s <- sd('x')
	return (s)
}

sd(c2$age)

